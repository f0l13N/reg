// Определяем функции для отображения сообщения об ошибке
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Определяем функции для проверки формы
function validateForm() {
    // Получение значений элементов формы
    var mobile = document.contactForm.mobile.value;
    var password = document.contactForm.password.value;
    var hobbies = [];
    var checkboxes = document.getElementsByName("hobbies[]");
    for(var i=0; i < checkboxes.length; i++) {
        if(checkboxes[i].checked) {
            // Заполняем массив хобби выбранными значениями
            hobbies.push(checkboxes[i].value);
        }
    }

    // Определяем переменные ошибок со значением по умолчанию
    var nameErr = emailErr = mobileErr = countryErr = genderErr = passwordErr = true;

    // Проверяем номер мобильного телефона
    if(mobile == "") {
        printError("mobileErr", "Пожалуйста, введите номер вашего мобильного телефона");
    } else {
        var regex = /^[1-9]\d{9}$/;
        if(regex.test(mobile) === false) {
            printError("mobileErr", "Пожалуйста, введите действительный 10-значный номер мобильного телефона");
        } else{
            printError("mobileErr", "");
            mobileErr = false;
        }
    }

    if(password == "") {
        printError("passwordErr", "Пожалуйста, введите пароль");
    } else {
        var regex = /^[1-9]\d{9}$/;
        if(regex.test(password) === false) {
            printError("passwordErr", "Пароль должен быть от 10 символов");
        } else{
            printError("passwordErr", "");
            passwordErr = false;
        }
    }



    // Запрещаем отправку формы в случае ошибок
    if((nameErr || emailErr || mobileErr || passwordErr || countryErr || genderErr) == true) {
       return false;
    } else {
        // Создаем строки из входных данных для предварительного просмотра
        var dataPreview = "Вы ввели следующие данные: \n" +
                          "Имя: " + name + "\n" +
                          "Email: " + email + "\n" +
                          "Номер: " + mobile + "\n" +
                          "Страна: " + country + "\n" +
                          "Пол: " + gender + "\n";
        if(hobbies.length) {
            dataPreview += "Hobbies: " + hobbies.join(", ");
        }
        // Отображаем входные данные в диалоговом окне перед отправкой формы
        alert(dataPreview);
    }
};
